import React from 'react'
import { View, Text, TextInput, StyleSheet } from 'react-native'
import { Feather } from '@expo/vector-icons'; 

function SearchBar({term, onTermChange}) {
  return (
      <View style={styles.backgroundStyle}>
          <Feather style={styles.iconStyle} name="search" size={35} color="black" /> 
          <TextInput style={styles.inputStyle}
              placeholder='Search'
              value={term}
              onTermChange={newTerm=>onTermChange(newTerm)}
            />
      </View>
  )
}

const styles = StyleSheet.create({
    backgroundStyle: {
        marginTop:10,
        backgroundColor: '#F0EEEE',
        height: 50,
        borderRadius: 5,
        marginHorizontal: 15,
        flexDirection:'row'
    },
    inputStyle: {
        flex: 1,
        fontSize:18
    },
    iconStyle: {
        alignSelf: 'center',
        marginHorizontal:15
    }
})

export default SearchBar